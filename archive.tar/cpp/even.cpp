#include<iostream>
using namespace std;

int main()
{
    int n = 88;
    if(n % 2 == 0)
        cout << "Even" << endl;
    
    return 0;
}