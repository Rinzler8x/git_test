#include<iostream>
using namespace std;

int main()
{
    cout << "Hello cpp" << endl;
}